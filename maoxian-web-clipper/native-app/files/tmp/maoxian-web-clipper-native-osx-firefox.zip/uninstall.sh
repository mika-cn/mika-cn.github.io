#!/usr/bin/env bash

APP_NAME="maoxian_web_clipper_native"

if [ "$(whoami)" = "root" ]; then
  TARGET_DIR="/Library/Application Support/Mozilla/NativeMessagingHosts"
else
  TARGET_DIR="$HOME/Library/Application Support/Mozilla/NativeMessagingHosts"
fi

rm "$TARGET_DIR/${APP_NAME}.json"
echo "Native messaging host $APP_NAME has been uninstalled."
