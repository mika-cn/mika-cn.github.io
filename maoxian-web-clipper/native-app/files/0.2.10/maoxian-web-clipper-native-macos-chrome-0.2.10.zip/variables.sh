#!/usr/bin/env bash

BROWSER_NAME="Google Chrome"
TARGET_DIR_SYSTEM="/Library/Google/Chrome/NativeMessagingHosts"
TARGET_DIR_USER="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
