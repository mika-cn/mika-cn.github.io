#!/usr/bin/env bash

BROWSER_NAME="Chromium"
TARGET_DIR_SYSTEM="/Library/Application Support/Chromium/NativeMessagingHosts"
TARGET_DIR_USER="$HOME/Library/Application Support/Chromium/NativeMessagingHosts"
