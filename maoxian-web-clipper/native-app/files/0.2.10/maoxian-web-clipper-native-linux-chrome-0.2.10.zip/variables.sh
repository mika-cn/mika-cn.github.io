#!/usr/bin/env bash

BROWSER_NAME="Google Chrome"
TARGET_DIR_SYSTEM="/etc/opt/chrome/native-messaging-hosts"
TARGET_DIR_USER="$HOME/.config/google-chrome/NativeMessagingHosts"
