#!/usr/bin/env bash

APP_NAME="maoxian_web_clipper_native"

if [ "$(whoami)" = "root" ]; then
  TARGET_DIR="/Library/Google/Chrome/NativeMessagingHosts"
else
  TARGET_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
fi

rm "$TARGET_DIR/${APP_NAME}.json"
echo "Native messaging host $APP_NAME has been uninstalled."
