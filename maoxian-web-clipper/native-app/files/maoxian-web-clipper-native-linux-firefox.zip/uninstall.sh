#!/usr/bin/env bash

APP_NAME="maoxian_web_clipper_native"

if [ "$(whoami)" = "root" ]; then
  TARGET_DIR="/usr/lib64/mozilla/native-messaging-hosts"
else
  TARGET_DIR="$HOME/.mozilla/native-messaging-hosts"
fi

rm "$TARGET_DIR/${APP_NAME}.json"
echo "Native messaging host $APP_NAME has been uninstalled."
