#!/usr/bin/env bash

set -e

# `realpath` is not avariable on Mac OS
function getpath(){
  perl -MCwd -e 'print Cwd::abs_path shift' "$1"
}

APP_NAME="maoxian_web_clipper_native"
DIR=$(dirname $(getpath "$0"))

# load variables
source $DIR/variables.sh

if [ "$(whoami)" = "root" ]; then
  TARGET_DIR="$TARGET_DIR_SYSTEM"
else
  TARGET_DIR="$TARGET_DIR_USER"
fi
TARGET_PATH="$TARGET_DIR/${APP_NAME}.json"

rm "$TARGET_PATH"
echo "[$BROWSER_NAME] Native messaging host $APP_NAME has been uninstalled."
echo "target: ${TARGET_PATH}"
