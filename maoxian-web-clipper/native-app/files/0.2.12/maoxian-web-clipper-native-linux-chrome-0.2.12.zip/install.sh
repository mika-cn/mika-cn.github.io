#!/usr/bin/env bash

set -e

# `realpath` is not avariable on Mac OS
function getpath(){
  perl -MCwd -e 'print Cwd::abs_path shift' "$1"
}

APP_NAME="maoxian_web_clipper_native"
DIR=$(dirname $(getpath "$0"))

# load variables
source $DIR/variables.sh

# target path
if [ "$(whoami)" = "root" ]; then
  TARGET_DIR="$TARGET_DIR_SYSTEM"
else
  TARGET_DIR="$TARGET_DIR_USER"
fi
TARGET_PATH="$TARGET_DIR/${APP_NAME}.json"

# create directory
mkdir -p "$TARGET_DIR"

# copy to manifest file to target dir
cp "$DIR/manifest.json" "$TARGET_PATH"

# Update host path in the manifest.
APP_PATH="$DIR/main.rb"
ESCAPED_APP_PATH=${APP_PATH////\\/}
sed -i -e "s/APP_PATH/$ESCAPED_APP_PATH/" "$TARGET_PATH"

# set permissions
chmod o+r "$TARGET_PATH"

echo "[$BROWSER_NAME] Native messaging host $APP_NAME has been installed."
echo "Target: ${TARGET_PATH}"
