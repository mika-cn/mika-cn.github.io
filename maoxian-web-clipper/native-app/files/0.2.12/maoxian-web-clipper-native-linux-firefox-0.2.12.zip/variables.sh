#!/usr/bin/env bash

BROWSER_NAME="Firefox"
TARGET_DIR_SYSTEM="/usr/lib64/mozilla/native-messaging-hosts"
TARGET_DIR_USER="$HOME/.mozilla/native-messaging-hosts"
