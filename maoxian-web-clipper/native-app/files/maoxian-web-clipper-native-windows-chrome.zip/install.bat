REG ADD "HKEY_CURRENT_USER\SOFTWARE\Google\Chrome\NativeMessagingHosts\maoxian_web_clipper_native" /ve /t REG_SZ /d "%~dp0manifest.json" /f
