@echo off

ruby "%~dp0/main.rb" %*
