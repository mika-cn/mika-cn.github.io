REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Google\Chrome\NativeMessagingHosts\maoxian_web_clipper_native" /f
REG DELETE "HKEY_CURRENT_USER\SOFTWARE\Google\Chrome\NativeMessagingHosts\maoxian_web_clipper_native" /f
