#!/usr/bin/env bash

BROWSER_NAME="Chromium"
TARGET_DIR_SYSTEM="/etc/chromium/native-messaging-hosts"
TARGET_DIR_USER="$HOME/.config/chromium/NativeMessagingHosts"
