#!/usr/bin/env bash

BROWSER_NAME="Firefox"
TARGET_DIR_SYSTEM="/Library/Application Support/Mozilla/NativeMessagingHosts"
TARGET_DIR_USER="$HOME/Library/Application Support/Mozilla/NativeMessagingHosts"
