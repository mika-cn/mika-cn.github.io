
# File intro
* $locale/message  => extension i18n
* $locale.json     => i18n.js
