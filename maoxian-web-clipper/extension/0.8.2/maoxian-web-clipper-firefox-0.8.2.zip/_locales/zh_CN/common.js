export default {
  // clipping attributes
  "g.clipping.title": "标题",
  "g.clipping.path": "路径",
  "g.clipping.time": "时间",
  "g.clipping.category": "目录",
  "g.clipping.tag": "标签",
  "g.clipping.tags": "标签",
  "g.clipping.format": "格式",
  "g.clipping.original-url": "原网址",
  "g.clipping.created-at": "创建时间",

  // task attributes
  "g.task.clipId": "Clipping ID",
  "g.task.clip-id": "Clipping ID",
  "g.task.filename": "文件名",
  "g.task.timeout": "超时时长",
  "g.task.tries": "最大尝试次数",
  "g.task.createdAt": "创建时间",
  "g.task.filenameAndUrl": "文件名和网址",

  // button labels
  "g.btn.save": "保存",
  "g.btn.confirm": "确认",
  "g.btn.delete": "删除",
  "g.btn.cancel": "取消",

  // labels
  "g.label.none": "无",
  "g.label.access": "访问",
  "g.label.warning": "警告",

  // hint
  "g.hint.no-record": "没有记录",
  "g.hint.saved": "已保存",
  "g.hint.update-success": "更新成功!",
  "g.hint.delete-success": "删除成功!",

  // options
  "g.option-value.html": "HTML",
  "g.option-value.md": "Markdown",

  // handlers
  "g.handler.browser.name": "浏览器",
  "g.handler.native-app.name": "本地程序",
  "g.handler.wiz-note-plus.name": "为知笔记",

  // errors
  "g.error.value-invalid": "输入值无效",
  "g.error.not-a-number": "输入值不是数字",
  "g.error.not-in-allowed-range": "输入值不在允许范围之内",

  "g.error.handler.not-enabled": "处理程序未启用",
  "g.error.handler.not-ready": "处理程序处于不可用状态",

};
