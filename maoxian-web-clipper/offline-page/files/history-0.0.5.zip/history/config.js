
const Config = {
  // Change me if your root folder is not "mx-wc".
  rootFolder: 'mx-wc',
}
