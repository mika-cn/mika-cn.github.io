/*!
 * This file is just a sample. Your can configure MaoXian Web Clipper to automate generate this file.
 */

var clippings = [
  {
    "category":"box/ipld",
    "clipId":"1545733320",
    "created_at":"2018-12-25 18:22:00",
    "filename":"index.html",
    "format":"html",
    "link":"https://github.com/ipld/ipld",
    "path":"mx-wc/box/ipld/2018-12-25-1545733320/index.json",
    "tags":["ipld"],
    "title":"[Sample history] GitHub - ipld/ipld: InterPlanetary Linked Data"
  },
  {
    "category":"box/ipfs",
    "clipId":"1545729812",
    "created_at":"2018-12-25 17:23:32",
    "filename":"index.html",
    "format":"html",
    "link":"https://docs.ipfs.io/introduction/usage/",
    "path":"mx-wc/box/ipfs/2018-12-25-1545729812/index.json",
    "tags":["ipfs-usage"],
    "title":"[Sample history] Basic Usage – IPFS Documentation"
  }
];
